# remove doc tags
cat wiki_* | sed '/<doc/d' | sed '/<\/doc>/d' > data.txt

# remove single-word lines, which indicate titles
sed -i '/^[A-Za-z][A-Za-z]*$/d' data.txt

# strip punctuation
sed -i 's/[[:punct:]]//g' data.txt

# lowercase
cat data.txt | tr '[[:upper:]]' '[[:lower:]]' > foo.txt; rm data.txt; mv foo.txt data.txt
