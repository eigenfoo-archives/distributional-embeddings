# remove doc tags
cat wiki_* | sed '/<doc/d' | sed '/<\/doc>/d' > data.txt

# strip punctuatio and remove single-word lines, which indicate titles
sed -i 's/\./$keep/g; s/[[:punct:]]//g; s/keep/\./g; /^[A-Za-z][A-Za-z]*$/d' data.txt
# lowercase
cat data.txt | tr '[[:upper:]]' '[[:lower:]]' > foo.txt; rm data.txt; mv foo.txt data.txt
